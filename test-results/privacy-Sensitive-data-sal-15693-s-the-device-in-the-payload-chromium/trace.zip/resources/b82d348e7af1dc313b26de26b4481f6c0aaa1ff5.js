(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__04kpziu._.css","static/chunks/node_modules_next_dist_20wefz_._.js","static/chunks/src_1_3r8cj._.js","static/chunks/node_modules_0wxpl2c._.js"],
    source: "entry"
});
